# AI9000
Python Implementation of a simple AI Q/A Answering System based on stories read.
